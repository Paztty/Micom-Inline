﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Micom_Inline
{
    public partial class Closing : Form
    {
        public Closing()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
        }

        private void OPForm_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
            }
        }

        private void OPForm_Load(object sender, EventArgs e)
        {

        }
    }
}
