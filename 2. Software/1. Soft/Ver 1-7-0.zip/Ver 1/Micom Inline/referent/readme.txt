****************************************************************************
*****         PG4UW Remote Control 64-bit library files                *****
*****           "remotelb.dll" and "RemotelbNET.dll"                   *****
****************************************************************************

User guide:

Use these dll's with your 64-bit remote control application.
(place both dll's into same folder, where your app is placed in).


Note(s):

PG4UW control program is still 32-bit, so preserve originally installed 
32-bit remotelb.dll and RemotelbNET.dll in folder, where PG4UW is installed in.
